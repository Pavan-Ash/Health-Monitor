#include <Wire.h>
#include <MAX30100_PulseOximeter.h>

#define REPORTING_PERIOD_MS 1000

PulseOximeter pox;
uint32_t lastReportTime = 0;

void onBeatDetected()
{
  Serial.println("Beat!");
}

void setup()
{
  Serial.begin(115200);

  Serial.println("Initializing MAX30100...");

  if (!pox.begin())
  {
    Serial.println("MAX30100 not found!");
    while (1);
  }

  pox.setIRLedCurrent(MAX30100_LED_CURR_7_6MA);
  pox.setOnBeatDetectedCallback(onBeatDetected);

  Serial.println("MAX30100 initialized.");
  Serial.println("Place your finger on the sensor.");
}

void loop()
{
  // Must be called continuously
  pox.update();

  if (millis() - lastReportTime >= REPORTING_PERIOD_MS)
  {
    lastReportTime = millis();

    Serial.print("Heart Rate: ");
    Serial.print(pox.getHeartRate());
    Serial.print(" BPM");

    Serial.print(" | SpO2: ");
    Serial.print(pox.getSpO2());
    Serial.println(" %");
  }
}