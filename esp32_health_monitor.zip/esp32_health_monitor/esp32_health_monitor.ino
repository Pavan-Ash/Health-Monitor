/**
 * ESP32 Health Monitor
 * Sensors: MAX30100 (HR + SpO2), AD8232 (ECG), MAX4466 (Mic/Respiration), DS18B20 (Temp)
 *
 * Required Libraries (install via Arduino Library Manager):
 *   - MAX30100lib       by OXullo Intersecans  (search: "MAX30100lib")
 *   - OneWire           by Jim Studt et al.
 *   - DallasTemperature by Miles Burton
 *
 * Pin Mapping:
 *   MAX30100 SDA  -> GPIO 21
 *   MAX30100 SCL  -> GPIO 22
 *   AD8232 OUTPUT -> GPIO 34
 *   AD8232 LO+    -> GPIO 32
 *   AD8232 LO-    -> GPIO 33
 *   MAX4466 OUT   -> GPIO 35
 *   DS18B20 DATA  -> GPIO 4  (+ 4.7kΩ pull-up to 3V3)
 */

#include <Wire.h>
#include <MAX30100_PulseOximeter.h>
#include <OneWire.h>
#include <DallasTemperature.h>

// ─── Pin Definitions ────────────────────────────────────────────────────────
#define ECG_OUTPUT_PIN   34   // AD8232 analog output (ADC1_CH6)
#define ECG_LO_PLUS_PIN  32   // Lead-off detection +
#define ECG_LO_MINUS_PIN 33   // Lead-off detection -
#define MIC_PIN          35   // MAX4466 analog output (ADC1_CH7)
#define DS18B20_PIN       4   // DS18B20 OneWire data

// ─── Timing Constants ────────────────────────────────────────────────────────
#define REPORTING_PERIOD_MS     1000   // Serial report interval (1 s)
#define TEMP_READ_INTERVAL_MS   5000   // DS18B20 read interval (5 s)
#define ECG_SAMPLE_INTERVAL_US  4000   // ECG sample every 4 ms → ~250 Hz
#define RESP_WINDOW_MS          5000   // Respiration estimation window (5 s)
#define RESP_THRESHOLD          150    // ADC threshold delta for breath detection

// ─── Objects ────────────────────────────────────────────────────────────────
PulseOximeter        pox;
OneWire              oneWire(DS18B20_PIN);
DallasTemperature    tempSensor(&oneWire);

// ─── Globals ────────────────────────────────────────────────────────────────
uint32_t lastReportTime   = 0;
uint32_t lastTempTime     = 0;
uint32_t lastEcgSample    = 0;
uint32_t respWindowStart  = 0;

float    currentTemp      = 0.0;
int      respirationRate  = 0;

// Respiration estimation state
int      breathCount      = 0;
int      prevMicValue     = 0;
bool     inBreath         = false;

// ECG buffer for serial plotter (last 10 values)
int      ecgBuffer[10];
int      ecgIdx = 0;

// ─── MAX30100 beat callback ───────────────────────────────────────────────
void onBeatDetected() {
  // Called by the MAX30100 library on each heartbeat detection
  Serial.println("[MAX30100] Beat detected!");
}

// ─── Setup ───────────────────────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  while (!Serial) delay(10);

  Serial.println("=== ESP32 Health Monitor ===");

  // ── AD8232 ECG ──────────────────────────────────────────────────────────
  pinMode(ECG_LO_PLUS_PIN,  INPUT);
  pinMode(ECG_LO_MINUS_PIN, INPUT);
  // GPIO 34 & 35 are input-only on ESP32; no pinMode needed for ADC

  // ── MAX30100 Pulse Oximeter ──────────────────────────────────────────────
  Serial.print("Initializing MAX30100... ");
  if (!pox.begin()) {
    Serial.println("FAILED. Check wiring (SDA=21, SCL=22).");
    // Non-fatal: continue without HR/SpO2
  } else {
    // Set IR LED current (options: 7.6mA, 11.0mA, 14.2mA, 17.4mA, 20.8mA, 24.0mA, 27.1mA, 50.0mA)
    pox.setIRLedCurrent(MAX30100_LED_CURR_7_6MA);
    pox.setOnBeatDetectedCallback(onBeatDetected);
    Serial.println("OK");
  }

  // ── DS18B20 Temperature ─────────────────────────────────────────────────
  tempSensor.begin();
  tempSensor.setResolution(12);          // 12-bit = 0.0625 °C resolution
  Serial.print("DS18B20 devices found: ");
  Serial.println(tempSensor.getDeviceCount());

  // ── Analog attenuation for ADC pins ────────────────────────────────────
  // ESP32 ADC full range = 0-3.3V with 11dB attenuation
  analogSetAttenuation(ADC_11db);
  analogReadResolution(12);              // 12-bit ADC (0–4095)

  // ── Init respiration window ─────────────────────────────────────────────
  respWindowStart = millis();
  prevMicValue    = analogRead(MIC_PIN);

  Serial.println("Setup complete. Starting monitoring...\n");
}

// ─── Respiration estimation (zero-crossing / threshold method) ────────────
void updateRespiration() {
  int micVal   = analogRead(MIC_PIN);
  int midpoint = 2048; // ~1.65V midpoint for MAX4466

  // Detect upward crossing of threshold above midpoint → one breath cycle
  bool currentlyAbove = (micVal > midpoint + RESP_THRESHOLD);
  if (currentlyAbove && !inBreath) {
    inBreath = true;
    breathCount++;
  } else if (!currentlyAbove) {
    inBreath = false;
  }

  // Every RESP_WINDOW_MS, calculate breaths per minute
  uint32_t now = millis();
  if (now - respWindowStart >= RESP_WINDOW_MS) {
    float minutes       = RESP_WINDOW_MS / 60000.0f;
    respirationRate     = (int)(breathCount / minutes);
    breathCount         = 0;
    respWindowStart     = now;
  }
  prevMicValue = micVal;
}

// ─── Read ECG sample ─────────────────────────────────────────────────────
int readECG() {
  // Check lead-off detection pins
  if (digitalRead(ECG_LO_PLUS_PIN) == HIGH || digitalRead(ECG_LO_MINUS_PIN) == HIGH) {
    return -1; // Leads not attached / poor contact
  }
  return analogRead(ECG_OUTPUT_PIN); // 0–4095
}

// ─── Print formatted report ───────────────────────────────────────────────
void printReport(float bpm, float spo2, int ecgVal, float tempC) {
  Serial.println("─────────────────────────────────────");
  Serial.printf("❤  Heart Rate  : %.0f BPM\n",   bpm  > 0 ? bpm  : 0);
  Serial.printf("🩸 SpO2        : %.0f %%\n",    spo2 > 0 ? spo2 : 0);
  Serial.printf("⚡ ECG Value   : %s\n",
    ecgVal == -1 ? "Leads off / no contact" : String(ecgVal).c_str());
  Serial.printf("🌡  Temperature : %.2f °C (%.2f °F)\n",
    tempC, tempC * 9.0 / 5.0 + 32.0);
  Serial.printf("🌬 Respiration : %d breaths/min\n", respirationRate);
  Serial.println("─────────────────────────────────────\n");
}

// ─── Arduino Serial Plotter output (comment out printReport, use this instead)
void plotterOutput(float bpm, float spo2, int ecgVal, float tempC) {
  // Format: BPM SpO2 ECG Temp  — view in Arduino Serial Plotter
  Serial.printf("BPM:%.0f SpO2:%.0f ECG:%d Temp:%.1f Resp:%d\n",
    bpm > 0 ? bpm : 0,
    spo2 > 0 ? spo2 : 0,
    ecgVal == -1 ? 2048 : ecgVal,
    tempC,
    respirationRate);
}

// ─── Main Loop ───────────────────────────────────────────────────────────────
void loop() {
  uint32_t now = millis();

  // ── 1. Update MAX30100 (must be called every loop iteration) ────────────
  pox.update();

  // ── 2. Sample ECG (250 Hz) ──────────────────────────────────────────────
  if ((micros() - lastEcgSample) >= ECG_SAMPLE_INTERVAL_US) {
    lastEcgSample = micros();
    // Store latest ECG reading for the report
    ecgBuffer[ecgIdx % 10] = readECG();
    ecgIdx++;
  }

  // ── 3. Update respiration (runs every loop, accumulates counts) ─────────
  updateRespiration();

  // ── 4. Read temperature every 5 s (DS18B20 conversion takes ~750ms) ────
  if (now - lastTempTime >= TEMP_READ_INTERVAL_MS) {
    lastTempTime = now;
    tempSensor.requestTemperatures();
    float t = tempSensor.getTempCByIndex(0);
    if (t != DEVICE_DISCONNECTED_C) {
      currentTemp = t;
    }
  }

  // ── 5. Report every second ──────────────────────────────────────────────
  if (now - lastReportTime >= REPORTING_PERIOD_MS) {
    lastReportTime = now;

    float bpm  = pox.getHeartRate();
    float spo2 = pox.getSpO2();
    int   ecg  = ecgBuffer[(ecgIdx - 1 + 10) % 10]; // most recent ECG sample

    // Use printReport() for human-readable output
    printReport(bpm, spo2, ecg, currentTemp);

    // Uncomment below (and comment printReport) for Arduino Serial Plotter:
    // plotterOutput(bpm, spo2, ecg, currentTemp);
  }
}
