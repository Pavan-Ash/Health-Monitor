#include <WiFi.h>
#include <WebServer.h>

// Configuration for Stage 1 (Setup Portal)
const char* ap_ssid = "ESP32_Setup_Portal";
const char* ap_password = "SetupPassword123";

WebServer server(80);

// Global variables to store credentials submitted via the webpage
String home_ssid = "";
String home_password = "";
bool credentials_received = false;

// HTML for the initial Setup Page (Stage 1)
void handleRoot() {
  String html = "<!DOCTYPE html><html><head>";
  html += "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">";
  html += "<style>html { font-family: Helvetica; text-align: center; margin-top: 50px;}";
  html += "input[type=text], input[type=password] { width: 80%; padding: 12px; margin: 8px 0; border: 1px solid #ccc; border-radius: 4px; }";
  html += "input[type=submit] { background-color: #4CAF50; color: white; padding: 14px 20px; border: none; border-radius: 4px; cursor: pointer; width: 84%; }";
  html += "</style></head><body>";
  html += "<h2>ESP32 Wi-Fi Setup</h2>";
  html += "<form action=\"/submit\" method=\"POST\">";
  html += "<label for=\"ssid\">Home Wi-Fi SSID:</label><br>";
  html += "<input type=\"text\" id=\"ssid\" name=\"ssid\" placeholder=\"Your Wi-Fi Name\"><br>";
  html += "<label for=\"pass\">Wi-Fi Password:</label><br>";
  html += "<input type=\"password\" id=\"pass\" name=\"pass\" placeholder=\"Your Wi-Fi Password\"><br><br>";
  html += "<input type=\"submit\" value=\"Connect\">";
  html += "</form></body></html>";

  server.send(200, "text/html", html);
}

// Handler for the form submission
void handleSubmit() {
  if (server.hasArg("ssid") && server.hasArg("pass")) {
    home_ssid = server.arg("ssid");
    home_password = server.arg("pass");
    
    String msg = "<!DOCTYPE html><html><body><h2>Credentials Received!</h2>";
    msg += "<p>Connecting to " + home_ssid + "... Check your Serial Monitor for the new IP.</p></body></html>";
    server.send(200, "text/html", msg);
    
    delay(2000); // Give the server time to send the response
    credentials_received = true; // Set flag to break out of setup loop
  } else {
    server.send(400, "text/plain", "Bad Request: Missing SSID or Password");
  }
}

// HTML for the destination webpage (Stage 2)
void handleHomeRoot() {
  String html = "<!DOCTYPE html><html><head>";
  html += "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">";
  html += "<style>html { font-family: Helvetica; text-align: center; margin-top: 50px;}";
  html += "h1 { color: #007BFF; }</style></head><body>";
  html += "<h1>Welcome to Stage 2!</h1>";
  html += "<p>The ESP32 is successfully connected to your home network.</p>";
  html += "</body></html>";

  server.send(200, "text/html", html);
}

void setup() {
  Serial.begin(115200);
  Serial.println("\n--- Starting Stage 1: Setup Portal ---");

  // Step 1: Start in Access Point Mode
  WiFi.softAP(ap_ssid, ap_password);
  Serial.print("Connect to Wi-Fi: ");
  Serial.println(ap_ssid);
  Serial.print("Go to IP: ");
  Serial.println(WiFi.softAPIP());

  // Setup routing for Stage 1
  server.on("/", handleRoot);
  server.on("/submit", HTTP_POST, handleSubmit);
  server.begin();

  // Wait right here until the user submits the form
  while (!credentials_received) {
    server.handleClient();
    delay(1);
  }

  // Step 2: Transition to Station Mode
  Serial.println("\n--- Starting Stage 2: Connecting to Home Network ---");
  
  // Stop the server and drop AP mode
  server.stop();
  WiFi.softAPdisconnect(true); 
  
  // Connect to your home router
  WiFi.begin(home_ssid.c_str(), home_password.c_str());
  
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 20) {
    delay(500);
    Serial.print(".");
    attempts++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nConnected successfully!");
    Serial.print("New Webpage Local IP Address: ");
    Serial.println(WiFi.localIP());

    // Clear old routing configurations and set up Stage 2 layout
    server.on("/", handleHomeRoot); 
    server.begin();
    Serial.println("New HTTP server started on home network.");
  } else {
    Serial.println("\nFailed to connect. Restarting ESP32...");
    delay(3000);
    ESP.restart(); // Reboot and try again if credentials were wrong
  }
}

void loop() {
  // Keep serving the Stage 2 webpage
  server.handleClient();
}